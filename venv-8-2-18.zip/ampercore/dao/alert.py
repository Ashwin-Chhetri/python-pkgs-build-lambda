""" Holds the AlertDao class. """
import copy
import json
from typing import List, Tuple

import pytz

from ampercore.dao.dao import BaseDao
from ampercore.objects.alert import Alert


class AlertDao(BaseDao):
    """ The AlertDao that can be used to access and store downtime alert objects. """
    table_name = "downtime_alerts"
    all_attributes = ["id", "title", "active", "factory_id", "machine_id", "start_time",
                      "end_time", "threshold", "alert_recipients", "notification_arn",
                      "created_at", "created_by", "deleted", "timed_out"]
    insert_attributes = [a for a in all_attributes if a not in ("id", "created_at", "deleted",
                                                                "timed_out")]

    def __init__(self, connection) -> None:
        BaseDao.__init__(self, connection)

    @staticmethod
    def all_attrs_to_alert(alert_row: Tuple) -> Alert:
        """ helper method that maps Alert rows to Alert object. """
        return Alert(
            alert_id=alert_row[0],
            title=alert_row[1],
            active=alert_row[2],
            factory_id=alert_row[3],
            machine_id=alert_row[4],
            start_time=int(alert_row[5].timestamp()),
            end_time=int(alert_row[6].timestamp()),
            threshold=alert_row[7],
            alert_recipients=alert_row[8],
            notification_arn=alert_row[9],
            created_at=int(alert_row[10].timestamp()),
            created_by=alert_row[11],
            deleted=alert_row[12],
            timed_out=alert_row[13])

    def get_alerts_for_factory(self, factory_id: int) -> List[Alert]:
        """
        Fetch all of the existing alerts for a given factory
        :param factory_id: int
        :return: List[Alert] objects
        """
        alert_query = "SELECT {attrs} FROM {table} WHERE factory_id=%s AND " \
                      "deleted=false ORDER BY id".format(attrs=", ".join(self.all_attributes),
                                                         table=self.table_name)
        self.cursor.execute(alert_query, (factory_id,))
        results = self.cursor.fetchall()
        return [self.all_attrs_to_alert(alert) for alert in results]

    def get_active_alerts(self, timestamp: int) -> List[Alert]:
        """
        Fetch all of the active alerts that at any given time. Checks the active flag as
        well as uses the time to make sure it is in-between start/end time.
        :param timestamp: epoch time
        :return: List[Alert]
        """
        alert_query = "SELECT {attrs} FROM {table} WHERE active=true AND " \
                      "start_time <= TO_TIMESTAMP(%s) AND end_time >= TO_TIMESTAMP(%s) " \
                      "AND deleted=false ORDER BY id".format(
                          attrs=", ".join(self.all_attributes),
                          table=self.table_name)

        self.cursor.execute(alert_query, (timestamp, timestamp,))
        results = self.cursor.fetchall()
        return [self.all_attrs_to_alert(alert) for alert in results]

    def insert(self, alert: Alert) -> Alert:
        """
        Insert a new alert into the database.
        :param alert: Alert object
        :return: updated Alert object
        """
        insert_query = "INSERT INTO {table} ({attrs}) VALUES (%s, %s, %s, %s, to_timestamp(%s), " \
                       "to_timestamp(%s), %s, %s, %s, %s) RETURNING id, " \
                       "created_at".format(attrs=", ".join(self.insert_attributes),
                                           table=self.table_name)

        self.cursor.execute(insert_query, (alert.title, alert.active, alert.factory_id,
                                           alert.machine_id, alert.start_time, alert.end_time,
                                           alert.threshold, json.dumps(alert.alert_recipients),
                                           alert.notification_arn, alert.created_by,))
        new_id, created_at = self.cursor.fetchone()
        self.connection.commit()

        new_alert = copy.copy(alert)
        new_alert.alert_id, new_alert.created_at = new_id, \
            int(created_at.replace(
                tzinfo=pytz.UTC).timestamp())

        return new_alert

    def update(self, alert: Alert) -> Alert:
        """
        Provided an existing alert object, check if exists, and then update all fields. If
        alert does not exist for a given idea, will raise a BaseException to be caught by
        the user.
        :param alert: Alert object
        :return: Alert object
        """
        if not alert.alert_id or alert.alert_id < 1:
            raise BaseException("Alert object must have alert_id set to update.")

        exists_query = "SELECT id FROM {table} WHERE id=%s".format(table=self.table_name)
        self.cursor.execute(exists_query, (alert.alert_id,))

        if not self.cursor.fetchone():
            raise BaseException("No alert found with id: {}".format(alert.alert_id))

        update_query = "UPDATE {table} SET title=%s, active=%s, factory_id=%s, machine_id=%s, " \
                       "start_time=to_timestamp(%s), end_time=to_timestamp(%s), threshold=%s, " \
                       "alert_recipients=%s, notification_arn=%s, deleted=%s " \
                       "WHERE id=%s".format(table=self.table_name)
        self.cursor.execute(update_query, (alert.title, alert.active, alert.factory_id,
                                           alert.machine_id, alert.start_time, alert.end_time,
                                           alert.threshold, json.dumps(alert.alert_recipients),
                                           alert.notification_arn, alert.deleted, alert.alert_id))
        self.connection.commit()
        return alert

    def update_field(self, alert_id: int, **kwargs) -> None:
        """
        Provided a field through kwargs, update that for a given id. If too many fields are
        passed at once, raise BaseException. If **kwarg is invalid column name, raises
        BaseException.
        :param alert_id: int
        :param kwargs: contains 1 field
        :return:
        """
        if len(kwargs) > 1:
            raise BaseException("update_field can only accept 1 kwarg field as of now.")

        if len(kwargs) < 1:
            raise BaseException("1 field must be set for update_field to update an alert.")

        field = next(iter(kwargs))
        if field not in self.all_attributes:
            raise BaseException("update_field requires an existing column field to be passed.")

        update_query = "UPDATE {table} SET {attr}=%s WHERE id=%s".format(table=self.table_name,
                                                                         attr=field)
        self.cursor.execute(update_query, (kwargs[field], alert_id,))
        self.connection.commit()
