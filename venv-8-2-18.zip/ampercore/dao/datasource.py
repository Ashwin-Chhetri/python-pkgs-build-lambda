""" Holds the DatasourceDao class. """
from datetime import timezone
from typing import List, Tuple

from ampercore.dao.dao import BaseDao
from ampercore.objects.datasource import Datasource


class DatasourceDao(BaseDao):  # pylint: disable=too-few-public-methods
    """ The DatasourceDao class can be used to access and store Datasource objects. """
    table_name = "datasources"
    all_attributes = ["id", "machine_id", "clamp_id", "created_at", "name", "active",
                      "description", "machine_type"]
    insert_attributes = [col for col in all_attributes if col not in "id"]

    def __init__(self, connection) -> None:
        BaseDao.__init__(self, connection)

    @staticmethod
    def all_attrs_to_datasource(datasource_row: Tuple) -> Datasource:
        """ Helper method that maps datasource row to Datasource object. """
        epoch_created_at = int(datasource_row[3].replace(tzinfo=timezone.utc).timestamp())
        return Datasource(
            ds_id=datasource_row[0],
            machine_id=datasource_row[1],
            clamp_id=datasource_row[2],
            created_at=epoch_created_at,
            name=datasource_row[4],
            active=datasource_row[5],
            description=datasource_row[6],
            machine_type=datasource_row[7],
        )

    def get(self, datasource_id: int) -> Datasource:
        """ Fetch a Datasource object by Id. Raises BaseException if not found. """
        datasource_query = "SELECT {attrs} FROM {table} WHERE id=%s".format(
            attrs=", ".join(self.all_attributes), table=self.table_name)
        self.cursor.execute(datasource_query, (datasource_id,))
        result = self.cursor.fetchone()

        if not result:
            raise BaseException("Datasource not found in DB with id: {}".format(datasource_id))

        return self.all_attrs_to_datasource(result)

    def get_list(self, **kwargs) -> List[Datasource]:
        """
        Higher level method that returns a list of datasources from a kwarg.
        :param kwargs: contains 1 field
        :return: List[Datasource]
        """
        return self._get(**kwargs)

    def _get(self, **kwargs) -> List[Datasource]:
        """
        Helper method that queries for a list of datasources based on some
        dynamic params. As of now, can only contain one field.
        :param kwargs: contains 1 field
        :return: List[Datasource]
        """
        if len(kwargs) != 1:
            raise BaseException("_get can only accept 1 kwarg query field as of now.")

        field = next(iter(kwargs))
        if field not in self.all_attributes:
            raise BaseException("_get requires an existing column field to be passed.")

        sql_query = "SELECT {attrs} FROM {table} WHERE {attr}=%s ORDER BY id".format(
            attrs=", ".join(self.all_attributes),
            table=self.table_name,
            attr=field)
        self.cursor.execute(sql_query, (kwargs[field],))
        results = self.cursor.fetchall()

        return [self.all_attrs_to_datasource(row) for row in results]
