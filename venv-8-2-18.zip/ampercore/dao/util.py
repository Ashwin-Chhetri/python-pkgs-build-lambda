""" Holds the UtilDao class. """
from ampercore.dao.dao import BaseDao
from ampercore.objects.util import FactoryOffset


class UtilDao(BaseDao):  # pylint: disable=too-few-public-methods
    """ THe UtilDao class can be used to access and store special utility objects. """

    def __init__(self, connection) -> None:
        BaseDao.__init__(self, connection)

    def get_factory_offset(self, datasource_id: int) -> FactoryOffset:
        """
        Fetches a FactoryOffset
        :param datasource_id:
        :return:
        """
        timezone_query = "SELECT f.name, fc.value FROM datasources ds JOIN machines m ON " \
                         "ds.machine_id=m.key JOIN factory f ON f.id=m.factory_id JOIN " \
                         "factory_config fc ON fc.factory_id=f.id WHERE ds.id=%s AND " \
                         "fc.field='timezone'"
        self.cursor.execute(timezone_query, (datasource_id, ))
        result = self.cursor.fetchone()

        if not result:
            raise BaseException("No factory timezone found for "
                                "datasource {}.".format(datasource_id))

        return FactoryOffset(
            factory_name=result[0],
            timezone_offset=int(result[1]),  # because the field value is generic, it is a str
        )
