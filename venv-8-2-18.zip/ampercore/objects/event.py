""" ampercore.objects.event holds classes that hold user event data that we want to. """
from typing import Any, Dict, Union


class Event(object):  # pylint: disable=too-few-public-methods
    """
    The base Event class that is used to represent time series events that occur throughout
    the amper application lifecycle.
    """

    def __init__(self,  # pylint: disable=too-many-arguments
                 event_id: int = -1,
                 timestamp: int = 0,
                 event_type: str = None,
                 action: str = None,
                 user_id: Union[int, None] = None,
                 metadata: Dict[str, Any] = None) -> None:
        """
        Constructor for the base Event class. All parameters are optional, and will default to
        sane default values if not specified.
        :param id: int, representing id in db
        :param timestamp: int, representing epoch time
        :param event_type: str, representing high level event type
        :param action: str, represents lower-level event specifics
        :param user_id: int, may be None
        """
        if not metadata:
            metadata = {}
        self.event_id = event_id
        self.timestamp = timestamp
        self.event_type = event_type
        self.action = action
        self.user_id = user_id
        self.metadata = metadata
