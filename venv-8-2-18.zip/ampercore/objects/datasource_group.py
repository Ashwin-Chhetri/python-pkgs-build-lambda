""" ampercore.objects.datasource_group holds datasource group objects. """
#  pylint: disable=too-many-arguments, too-few-public-methods


class DatasourceGroupMember(object):
    """
    DatasourceGroup is the object that represents objects from the ds_groups table.
    """

    def __init__(self,
                 ds_group_member_id: int = -1,
                 ds_group_id: int = -1,
                 datasource_id: int = -1,
                 x_co: int = -1,
                 y_co: int = -1) -> None:

        """
        Constructor of Datasource object.
        :param ds_group_member_id: int, unique id of datasources_ds_groups in db
        :param ds_group_id: int, id of the ds_group that this member belongs to
        :param datasource_id: int, id of the datasource this membership refers to
        :param x_co: int, int representing the x coordinate of the datasource in the group
        :param y_co: int, int representing the y coordinate of the datasource in the group
        """
        self.ds_group_member_id = ds_group_member_id
        self.ds_group_id = ds_group_id
        self.datasource_id = datasource_id
        self.x_co = x_co
        self.y_co = y_co


class DatasourceGroup(object):
    """
    DatasourceGroup is the object that represents objects from the ds_groups table.
    """

    def __init__(self,
                 ds_group_id: int = -1,
                 name: str = None,
                 factory_id: int = -1) -> None:

        """
        Constructor of Datasource object.
        :param ds_group_id: int, unique id of ds_groups in db
        :param name: str, name of the group this ds_group represents
        :param factory_id: int, id of the factory to which this group belongs
        """
        self.ds_group_id = ds_group_id
        self.name = name
        self.factory_id = factory_id
        self.datasources = []

    def add_datasource(self, datasource: DatasourceGroupMember) -> None:
        """
        Setter for datasources that are part of group.
        :param datasource: DatasourceGroupMember, instance of
            datasource as group member (includes x/y coordinates)
        """
        self.datasources.append(datasource)
