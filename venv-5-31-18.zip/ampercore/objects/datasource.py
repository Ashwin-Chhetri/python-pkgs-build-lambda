""" Holds the objects surrounding datasources, unique data streams. """
#  pylint: disable=too-many-arguments, too-few-public-methods


class Datasource(object):
    """
    class representing individual data sources throughout amper application services.
    """

    def __init__(self,
                 ds_id: int = -1,
                 machine_id: str = "zzzzz",
                 clamp_id: str = "c0",
                 name: str = None,
                 description: str = None,
                 active: bool = True,
                 created_at: int = -1,
                 machine_type: str = None) -> None:
        """
        Constructor of Datasource object.
        :param ds_id: int, unique id of datasource in db
        :param machine_id: str - hash representing devices
        :param clamp_id: str - clamp in ('c1', 'c2', ..)
        :param name: str, name of the source this datasource represents
        :param description: str, description of the datasource
        :param active: bool, is datasource visible or not
        :param created_at: int, epoch time of when datasource was created
        """
        self.ds_id = ds_id
        self.machine_id = machine_id
        self.clamp_id = clamp_id
        self.name = name
        self.description = description
        self.active = active
        self.created_at = created_at
        self.machine_type = machine_type
