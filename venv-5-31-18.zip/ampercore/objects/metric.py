"""
ampercore.objects.metric holds classes and data structures to make handling data more
consistent throughout all Python application services.
"""
#  pylint: disable=too-few-public-methods,too-many-arguments
from decimal import Decimal, getcontext
from enum import Enum, unique

getcontext().prec = 6


class Metric(object):
    """
    The base Metric class that is used to represent time series metrics used throughout
    our application services. See below for required data attributes
    """

    def __init__(self, timestamp: int, datasource_id: int, period: int) -> None:
        """
        Constructor for the metric base class.
        :param timestamp: int, representing epoch time of metric recording
        :param datasource_id: int, representing datasource
        :param period: int, representing how long metric covers, in milliseconds
        """
        self.timestamp = timestamp
        self.datasource_id = datasource_id
        self.period = period


class DerivedMetric(object):
    """
    The DerivedMetric class is a class that represents that a metric is derived via some
    algorithm in the Amper ecosystem.
    """

    def __init__(self, algorithm_id: int) -> None:
        """
        Constructor for DerivedMetric. Only requires an algorithm id to help label the
        metric source.
        :param algorithm_id: int
        """
        self.algorithm_id = algorithm_id


@unique
class StateType(Enum):
    """
    Enum class used to add some type safety around states used throughout the application.
    """
    Idle = "Idle"
    Lost = "Lost"
    Off = "Off"
    Production = "Production"
    Setup = "Setup"


class MachineState(Metric, DerivedMetric):
    """
    The MachineState class represents the state of a machine at a given point in time.
    It extends both Metric and DerivedMetric via multiple inheritance.
    """

    def __init__(self, algorithm_id: int, timestamp: int, datasource_id: int,
                 period: int, state: StateType) -> None:
        """
        Constructor for MachineState object.
        :param algorithm_id: int, representing an algorithm source id
        :param timestamp: int, epoch time
        :param datasource_id: int, representing a unique datasource.
        :param period: int, representing length of time metric spans, in milliseconds
        :param state: StateType, instance of StateType enum
        """
        Metric.__init__(self, timestamp, datasource_id, period)
        DerivedMetric.__init__(self, algorithm_id)
        self.state = state


class Amperage(Metric):
    """
    Amperage object represents the amount of electricity used by a machine at a given
    time point.
    """

    def __init__(self, timestamp: int, datasource_id: int, period: int,
                 amps: Decimal) -> None:
        """
        Constructor for Amperage object.
        :param timestamp: int, epoch time
        :param datasource_id: int, represent
        :param period:
        :param amps: Decimal
        """
        Metric.__init__(self, timestamp, datasource_id, period)
        self.amps = amps
