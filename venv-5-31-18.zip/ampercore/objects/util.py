""" Holds small/utility objects that don't necessarily fit anywhere else. """


class FactoryOffset(object):  # pylint: disable=too-few-public-methods
    """ Holds information about the details of a Factory timezone. """

    def __init__(self,
                 factory_name: str = "",
                 timezone_offset: int = -1) -> None:
        """
        Constructs the FactoryOffset object
        :param factory_name: str, defaults to empty str
        :param timezone_offset: int representing UTC offset, defaults to -1
        """
        self.factory_name = factory_name
        self.timezone_offset = timezone_offset
