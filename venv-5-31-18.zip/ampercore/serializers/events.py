""" Holds the EventSerializer, used to write Events to str for storage. """
from json import JSONEncoder

from ampercore.objects.event import Event


class EventSerializer(JSONEncoder):
    """ Custom implementation of JSONEncoder to serialize Event to json str. """

    def default(self, o):  # pylint: disable=method-hidden
        """ boilerplate method required by JSONEncoder to handle Event objects. """
        if isinstance(o, Event):
            return {
                "event_id": o.event_id,
                "timestamp": o.timestamp,
                "event_type": o.event_type,
                "action": o.action,
                "user_id": o.user_id,
                "metadata": o.metadata,
            }
        return JSONEncoder.default(self, o)
