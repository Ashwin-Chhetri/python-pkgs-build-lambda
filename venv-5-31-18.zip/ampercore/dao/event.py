""" Holds the EventDao class. """
import json
from typing import List

from ampercore.dao.dao import BaseDao
from ampercore.objects.event import Event


class EventDao(BaseDao):  # pylint: disable=too-few-public-methods
    """ The EventDao can be used to access and store Event objects. """
    table_name = "amper_events"
    all_attributes = ["id", "created_at", "event_type", "action", "user_id", "metadata"]
    insert_attributes = [col for col in all_attributes if col != "id"]

    def __init__(self, connection) -> None:
        """ Initialize EventDao. """
        BaseDao.__init__(self, connection)

    def batch_insert(self, events: List[Event]) -> None:
        """ Provided a list of Event objects, insert them all into the DB. """
        insert_query = "INSERT INTO {table} ({attrs}) SELECT TO_TIMESTAMP(UNNEST(%(ts)s)), \
                        UNNEST(%(event_type)s), UNNEST(%(action)s), UNNEST(%(user_id)s), \
                        CAST(UNNEST(%(metadata)s) AS json)".format(table=self.table_name,
                                                                   attrs=", ".join(
                                                                       self.insert_attributes))
        input_object = {
            "ts": [event.timestamp for event in events],
            "event_type": [event.event_type for event in events],
            "action": [event.action for event in events],
            "user_id": [event.user_id for event in events],
            "metadata": [json.dumps(event.metadata) for event in events],
        }
        self.cursor.execute(insert_query, input_object)
        self.connection.commit()
