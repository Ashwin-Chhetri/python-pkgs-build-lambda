""" Holds the heartbeater service that can be used in various amper tools. """
import logging

logger = logging.getLogger(__name__)  # pylint: disable=invalid-name


class HeartBeater(object):  # pylint: disable=too-few-public-methods
    """
    HeartBeater is used to record when key events happen, that allow for monitoring
    and triggering of alerts when necessary.
    """

    def __init__(self, service: str, connection) -> None:
        """
        Initialize HeartBeater with a psycopg2 connection instance. Service is the name
        of the broad service that will get recorded in the HeartBeater table. When
        actually using the HeartBeater, you will beat on events that follow underneath
        specific services.
        :param service: str
        :param connection: psycopg2 connection
        """
        cursor = connection.cursor()
        self.connection = connection
        self.cursor = cursor
        self.service = service

    def beat(self, event_name: str, timeout: int = 60) -> None:
        """
        Triggering a "beat", or updating the last_received service inside a table. This is
        wrapped up in a broad try/except to prevent issues with the HB from affecting
        your production services.
        :param event_name: str, represents the specific event for a given service you are
        monitoring.
        :param timeout: int, the number of seconds before the heartbeater parent raises the
        alarm about a missing event. Defaults to 60 seconds.
        :return: None
        """
        try:
            upsert_query = "INSERT INTO heartbeater (service, event_name, timeout, " \
                           "last_received) VALUES (%s, %s, %s, NOW())" \
                           "ON CONFLICT ON CONSTRAINT heartbeater_service_key " \
                           "DO UPDATE SET timeout=%s, last_received=NOW()"
            self.cursor.execute(upsert_query, (self.service, event_name, timeout, timeout,))

            rowcount = self.cursor.rowcount
            if rowcount != 1:
                logger.warning("Hearbeater updated %s rows, should've updated just 1.", rowcount)

            self.connection.commit()
        except BaseException as err:
            logger.warning("Hearbeater unable to beat successfully with err: %s", err)
