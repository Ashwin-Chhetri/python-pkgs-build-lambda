""" Module initializer for ampercore, sets __version__ namespace. """

from .version import __version__
