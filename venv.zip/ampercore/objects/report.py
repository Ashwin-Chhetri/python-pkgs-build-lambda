""" ampercore.objects.report holds report data objects. """
from enum import Enum, unique
from datetime import date
from typing import List
from uuid import uuid4


@unique
class ReportType(Enum):
    """
    ReportType is an enum object to add type safety to report types.
    """
    Utilization = "utilization"
    DetailedUtil = "detail_utilization"
    MachineTimelineByMachine = "machine_timeline_by_machine"
    MachineTimelineByDay = "machine_timeline_by_day"


@unique
class TimeFrame(Enum):
    """
    TimeFrame is an enum object that adds safety around time frames for reports.
    """
    Weekly = "weekly"
    Monthly = "monthly"


@unique
class ReportStatus(Enum):
    """
    ReportStatus is an enum object that adds safety around different states of reports.
    """
    InProgress = "in_progress"
    Completed = "completed"
    Failed = "failed"
    DataProcessing = "data_processing"
    BuildingPdf = "building_pdf"


class CustomerReport(object):  # pylint: disable=too-few-public-methods,R0902
    """
    CustomerReport is the object that represents objects from the customer_reports table.
    """

    def __init__(self,  # pylint: disable=too-many-arguments
                 report_hash: str = uuid4().hex,
                 factory_id: int = None,
                 report_type: ReportType = ReportType.Utilization,
                 timeframe: TimeFrame = TimeFrame.Weekly,
                 start_date: date = date.today(),
                 end_date: date = date.today(),
                 status: ReportStatus = ReportStatus.InProgress,
                 requested_at: int = None,
                 pdf_loc: str = None,
                 data_loc: str = None,
                 machines: List[int] = None,
                 requested_by: int = None):
        """
        Customer report constructor that includes some sane defaults. Important identifiers
            default to None if this is a new object.
        :param report_hash: str
        :param factory_id: int
        :param report_type: ReportType enum
        :param timeframe: TimeFrame enum
        :param start_date: date, built-in python objects
        :param end_date: date, built-in python objects
        :param status: ReportStatus enum
        :param requested_at: int, representing epoch time
        :param pdf_loc: str, s3 key that holds the pdf file
        :param data_loc: str, s3 key that holds the data blob
        :param machines: List[int], list of datasource ids
        :param requested_by: int of user who requested this object
        """
        self.hash = report_hash
        self.factory_id = factory_id
        self.type = report_type
        self.timeframe = timeframe
        self.start_date = start_date
        self.end_date = end_date
        self.status = status
        self.requested_at = requested_at
        self.pdf_loc = pdf_loc
        self.data_loc = data_loc
        if machines is None:
            machines = []
        self.machines = machines
        self.requested_by = requested_by
