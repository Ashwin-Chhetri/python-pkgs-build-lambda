""" ampercore.dao.dao holds the base Dao class that other dao objects extend. """


class BaseDao():  # pylint: disable=too-few-public-methods
    """ Base dao class that all other dao classes inherit from. """

    def __init__(self, connection) -> None:
        """ Attach the cursor and connection. """
        self.cursor = connection.cursor()
        self.connection = connection
