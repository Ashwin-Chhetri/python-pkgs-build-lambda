""" Holds the classes that are used for processing packets sent via mqtt. """
from typing import Any, Dict


class DataPoint(object):
    """
    Datapoint represents a single datapoint with a device id, clamp #, current val,
    and timestamp.
    """

    def __init__(self,
                 timestamp: int = 0,
                 device_id: str = "",
                 clamp: str = "",
                 current: float = 0.0):
        """ Initializes a DataPoint object. """
        self.timestamp = timestamp
        self.device_id = device_id
        self.clamp = clamp
        self.current = current

    @property
    def datasource_key(self) -> str:
        """
        Used to generate the unique key for a datasource from device/clamp.
        :param device_id: str - ie. d, b, c, etc.
        :param clamp: str - ie. c1, c2, c3, etc.
        :return: str
        """
        return "{}_{}".format(self.device_id, self.clamp)

    def __eq__(self, other):
        """ Custom equality method. """
        return self.__dict__ == other.__dict__

    def as_kinesis_record(self) -> Dict[str, Any]:
        """
        Returns a dictionary object that is formatted for publishing into kinesis.
        :return: {
            "time": 123123123,
            "key": "m_c3",
            "val": 19.23123
        }
        """
        return {
            "time": self.timestamp,
            "key": self.datasource_key,
            "val": self.current,
        }
