""" ampercore.objects.alert holds the objects that represent alerts. """
from typing import Any, List


class Alert(object):  # pylint: disable=too-few-public-methods
    """
    Alert is the object that represents alerts in the downtime_alerts table.
    """

    def __init__(self,  # pylint: disable=too-many-arguments,R0902,R0914
                 alert_id: int = -1,
                 title: str = None,
                 active: bool = True,
                 factory_id: int = None,
                 machine_id: int = None,
                 start_time: int = None,
                 end_time: int = None,
                 threshold: int = None,
                 alert_recipients: List[Any] = None,
                 notification_arn: str = None,
                 created_at: int = None,
                 created_by: int = None,
                 deleted: bool = False,
                 timed_out: bool = False):
        """
        Constructor for the alert object.
        :param alert_id: int, defaults to -1 if not provided
        :param title: str, title of alert
        :param active: bool, whether or not alert is active
        :param machine_id: int, representing which datasource this maps to
        :param start_time: int, alert start epoch time
        :param end_time: int, alert end epoch time
        :param threshold: int, time in minutes of allowed downtime before alert fires
        :param alert_recipients: List of objects that contain info about alert recipients
        :param notification_arn: str, representing arn of sns topic for users
        :param created_at: int, epoch time of alert creation
        :param created_by: int, id of customer id
        :param deleted: bool, represents whether report is deleted or not.
        """
        self.alert_id = alert_id
        self.title = title
        self.active = active
        self.factory_id = factory_id
        self.machine_id = machine_id
        self.start_time = start_time
        self.end_time = end_time
        self.threshold = threshold
        self.alert_recipients = alert_recipients
        self.notification_arn = notification_arn
        self.created_at = created_at
        self.created_by = created_by
        self.deleted = deleted
        self.timed_out = timed_out
