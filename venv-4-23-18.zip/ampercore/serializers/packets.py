""" Holds serializer classes that can be used to produce DataPacket classes. """
from typing import List

from ampercore.objects.packet import DataPoint


class RawEnergySerializer(object):  # pylint: disable=too-few-public-methods
    """ Holds methods that can be used to parse out DataPacket objects. """

    @staticmethod
    def parse_datapoints(message: str) -> List[DataPoint]:
        """
        Returns a list of DataPoint
        :param message: str
        :return: List[DataPoint]
        """
        # first, split the whole string on semi-colons with an array, A
        large_array = message.split(";")  # type: List[str]

        # grab the first element of array A, then split on colon
        # the second element of the resulting array B is the id
        id_array = large_array[0].split(":")  # type: List[str]
        device_id = id_array[1]  # type: str

        # take the second element of array A, and split on '='
        # the second element of the resulting array C is the time
        time_array = large_array[1].split("=")
        timestamp = int(time_array[1])  # type: int

        datapoints = []

        # loop from the 3rd element to the end, these are all the respective clamps
        for clamp in large_array[2:]:
            # within each iteration, split the element on ':' to give an array D
            # take the second element of array D and split on ',' to give array E
            clamp_array = clamp.split(":")  # type: List[str]
            data_array = clamp_array[1].split(",")  # type: List[str]

            # filter out empty
            cleaned_data_array = filter(None, data_array)

            for idx, val in enumerate(cleaned_data_array):
                if val == "x":
                    continue

                datapoints.append(DataPoint(
                    timestamp + idx,
                    device_id,
                    clamp_array[0],
                    float(val),
                ))

        return datapoints
